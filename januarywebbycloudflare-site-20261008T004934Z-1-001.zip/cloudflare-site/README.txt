January 26th Webinar Funnel — Cloudflare Pages folder

Pages:
  index.html      = The 5k Blueprint Training Version 2 (registration)
  thank-you.html  = Thank you for registering

Upload: Cloudflare → Workers & Pages → Create → Pages → Upload assets → drop this folder (or zip).

Notes:
  - Built from ClickFunnels HTML + asset folders. Google Docs are stubs only.
  - ClickFunnels badge / extension junk removed; assets under assets/.
  - If videos use Wistia, keep Cloudflare Rocket Loader OFF.
